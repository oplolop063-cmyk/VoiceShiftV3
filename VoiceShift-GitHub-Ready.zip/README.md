# VoiceShift APK

GitHub Actions will build the Android APK automatically.

## Build
1. Open the **Actions** tab.
2. Select **Build VoiceShift APK**.
3. Click **Run workflow**.
4. When it finishes, open the workflow run and download **VoiceShift-APK** from Artifacts.
